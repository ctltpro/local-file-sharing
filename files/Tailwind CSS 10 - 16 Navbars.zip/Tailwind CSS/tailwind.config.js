/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,js}"],
  theme: {
    extend: {
      backgroundImage: theme => ({
        small : "url('/images/women.jpg')",
        large : "url('/images/womenShopping.jpg')",
        shipsmall : "url('/images/ship-small.jpg')",
        shiplarge : "url('/images/ship-large.jpg')"
      })
    },
  },
  plugins: [],
}
